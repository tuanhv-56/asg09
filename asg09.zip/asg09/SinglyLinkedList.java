//class SinglyLinkedList.java
import java.io.*;

class Node <Item>
{
	Item data;
	Node next;
  public Node(Item str)
  {
	data = str;
	next = null;
  }
}
public class SinglyLinkedList <Item>{
  protected Node head;
  //protected Node tail;
  
  public SinglyLinkedList()
  {
	head = null;//tail = null;
  }
  public Node first() {
	return head;
  } // tra ve nut dau danh sach
  public Node last() {
	Node p = head;
	while(p.next!=null)
		p = p.next;
	return p;
  } // tra ve nut cuoi danh sach
  public Node next(Node n) {
	while(head!=null)
	{
		return n.next;
	}
	return n.next;
  } // tra ve nut lien sau n
  public Node prev(Node n) 
  {
	Node pre = null;
	pre.next = n;
	if(head == n)
	{
		return null;
	}
	else
	{
		pre = head;
		while(pre != n)
			pre = pre.next;
	}
	return pre;
  } // tra ve nut lien truoc n
  
  
  public <Item> Node remove(Node n) {
    // xoa nut n va tra ve du lieu cua nut duoc thao ra
	Node p = null;
	Node tail = head;
	while(tail.next!=null)
		tail = tail.next;
	if(n == null)
	{
		return null;
	}else
	if(last() == n)
	{
		p = head;
		while(p.next!=tail)
		{
			p = p.next;
		}
		//p.next = null;
		tail = p;
		p.next = null;
		//n = null;
	}
	else
	if(head == n)
	{
		p = head;
		head = head.next;
		//p = null;
		n = null;
	}
	else
	{
		//Node q = null;
		p.next = n;
		p.next = n.next;
		//q = n;
		n = null;
	}
	//return p.data;
	return p;
  }
  
  public Node insertAfter(Node n, Item s) {
    // chen du lieu s vao nut moi nam sau nut n,
	// tra ve tham chieu toi nut moi
	Node p = new Node(s);
	Node tail = head;
	while(tail.next!=null)
		tail = tail.next;
		
	if(n==null)
		return null;
	/*else if(n == last())
	{
		p.next = n.next;
		n.next = p;
		last() = p;
	}*/
	if(head == null)
	{
		head = tail = p;
	}
	else
	{
		p.next = n.next;
		n.next = p;
	}
	return p;
  }
  
  public Node insertBefore(Node n, Item s) {
    // chen du lieu s vao nut moi nam truoc nut n
	// tra ve tham chieu toi nut moi
	Node p = new Node(s);
	Node pre = null;
	Node tail = head;
	while(tail.next!=null)
		tail = tail.next;
		
	if(n == null)
		return null;
	if(head == null)
		head = tail = p;
	if(head == n)
	{
		p.next = head;
		head = p;
	}
	else
	{
		pre = head;
		while(pre.next!=n)
			pre = pre.next;
		pre.next = n;
		p.next = n;//(p.next = pre.next)
		pre.next = p;
	}
	return p;
  }
  
  public Node insertFirst(Item s) {
    // chen du lieu s vao nut moi nam dau danh sach
	// tra ve tham chieu toi nut moi
	Node p = new Node(s);
		
	if(head == null)
	{
		head = p;// tail = p;
	}
	else
	{
		p.next = head;
		head = p;
	}
	return head;
  }
 
  public Node insertLast(Item s) {
    // chen du lieu s vao nut moi nam cuoi danh sach
	// tra ve tham chieu toi nut moi
	Node p = new Node(s);
	Node tail = head;
	while(tail.next!=null)
		tail = tail.next;
	if(head == null)
	{
		head = tail = p;
	}
	else
	{
		tail.next = p;
		tail = p;
	}
	return tail;
  }
  public boolean empty()
  {
	return (head==null);
  }
  public void print()
  {
	Node p;// = new Node();
	for(p = head;p!=null;p=p.next)
		System.out.printf(p.data + " ");
  }
}