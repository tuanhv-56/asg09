//class TestHashMap.java
import java.util.*;
public class TestHashMap
{
	public static void main(String [] args)
	{
		Map phoneDir = new HashMap();
		phoneDir.put("12345",new String("Club soccer"));
		phoneDir.put("56789",new String("Club Student"));
		phoneDir.put("11223344",new String("Club Bia"));
		phoneDir.put("55667788",new String("Club fly"));
		
		System.out.println(phoneDir);
		phoneDir.remove("12345");
		System.out.println("List map after delete: " + phoneDir);
		
		phoneDir.put("55667788",new String("Club tenis"));
		System.out.println(phoneDir);
		
		Set entries = phoneDir.entrySet();
		Iterator iter = entries.iterator();
		while(iter.hasNext())
		{
			Map.Entry entry = (Map.Entry)iter.next();
			String key = (String)entry.getKey();
			String value = (String)entry.getValue();
			System.out.println("Key: " + key + ", value: " + value);
		}
	}
}