//class GenericListTest.java
import java.util.Scanner;
public class GenericListTest
{
	public static void main(String [] args)
	{
		SinglyLinkedList<String> p = new SinglyLinkedList<String>();
		
		String s1 = new String();
		String s2 = new String();
		Scanner input = new Scanner(System.in);
		
		p.<String>insertFirst("cong");
		p.<String>insertFirst("hoa");
		System.out.printf("List string after insertFirts: " + "\n");
		p.print();
		System.out.printf("\nList Empty: " + p.empty() + "\n");
		System.out.print("Please enter string s1 to insertLast: ");
		
		p.<String>insertLast("xa");
		System.out.printf("\nList string after insertLats: " + "\n");
		p.print();
		
		System.out.print("\nList string after delete first: \n");
		p.<String>remove(p.first());
		p.print();
		
		System.out.print("List string after delete null: " + "\n");
		p.<String>remove(null);
		p.print();
		
		System.out.print("\nList string after delete last: \n");
		p.<String>remove(p.last());
		p.print();
		
		System.out.print("\nList string after insert null: " + "\n");
		p.<String>insertAfter(null,"null");
		p.print();
		
		System.out.print("\nList string after insertBefore first: " + "\n");
		p.<String>insertBefore(p.first(),"hoi");
		p.print();
		
		System.out.print("\nList string after insertBefore last: " + "\n");
		p.<String>insertBefore(p.last(),"chu");
		p.<String>insertBefore(p.last(),"nghia");
		p.print();
		
		System.out.print("\nList string after insertAfter last: " + "\n");
		p.<String>insertAfter(p.last(),"viet");
		p.<String>insertAfter(p.last(),"nam");
		p.print();
		
		System.out.print("\nList string after insertAfter first: " + "\n");
		p.<String>insertAfter(p.first(),"cong");
		p.print();
		
		SinglyLinkedList<Integer> p2 = new SinglyLinkedList<Integer>();
		System.out.print("\nList number Integer after insert: " + "\n");
		p2.<Integer>insertFirst(10);
		p2.<Integer>insertLast(20);
		p2.<Integer>insertBefore(p2.first(),100);
		p2.<Integer>insertAfter(p2.last(),200);
		p2.<Integer>insertAfter(p2.first(),300);
		p2.print();
	}
}